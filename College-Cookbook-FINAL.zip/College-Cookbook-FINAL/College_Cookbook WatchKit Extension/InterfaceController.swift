//
//  InterfaceController.swift
//  College_Cookbook WatchKit Extension
//
//  Created by Jason Wallenfang on 4/16/17.
//  Copyright © 2017 CollegeCB_Team. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {

    let recipies = ["Boil Water","Grilled Cheese","Mac and Cheese","Tacos","Pan-fried Chicken","Chicken Alfredo","Cocolate Chip Cookies","Eggs"]
    let images = [#imageLiteral(resourceName: "water"),#imageLiteral(resourceName: "grilledcheese"),#imageLiteral(resourceName: "mac"),#imageLiteral(resourceName: "tacos"),#imageLiteral(resourceName: "chicken"),#imageLiteral(resourceName: "alfredo"),#imageLiteral(resourceName: "cookies"),#imageLiteral(resourceName: "eggs")]
    let dict = Dictionary<String,Array<String>>()

    @IBOutlet var table: WKInterfaceTable!
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        loadtabdata()
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    private func loadtabdata(){
        table.setNumberOfRows(recipies.count, withRowType: "TableController")
        for (index,recipie) in recipies.enumerated(){
            let row = table.rowController(at: index) as! TableController
            row.label.setText(recipie)
            //row.image.setImage(UIImage(named:recipePic))
        }
        for(index,images) in images.enumerated(){
            let row = table.rowController(at: index) as! TableController
            row.image.setImage(images)
        }
    }
    override func table(_ table: WKInterfaceTable, didSelectRowAt rowIndex: Int) {
        self.pushController(withName: "InstructionController", context: recipies[rowIndex])
    }

}
