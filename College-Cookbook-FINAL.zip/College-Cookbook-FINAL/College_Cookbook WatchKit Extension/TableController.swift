//
//  TableController.swift
//  College_Cookbook
//
//  Created by Clulo, Ryan on 5/3/17.
//  Copyright © 2017 CollegeCB_Team. All rights reserved.
//

import WatchKit

class TableController: NSObject {

    @IBOutlet var label: WKInterfaceLabel!
    @IBOutlet var image: WKInterfaceImage!
}
