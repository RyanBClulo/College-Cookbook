//
//  InstructionController.swift
//  College_Cookbook
//
//  Created by Clulo, Ryan on 5/3/17.
//  Copyright © 2017 CollegeCB_Team. All rights reserved.
//

import WatchKit
import Foundation


class InstructionController: WKInterfaceController {
    
    @IBOutlet var RecipieTitle: WKInterfaceLabel!
    @IBOutlet var steps: WKInterfaceLabel!
    
    @IBAction func swiper(_ sender: Any) {
        stepsPlace+=1
        if stepsPlace>stepsArr.count-1 {
            steps.setText("end")
        }
        else{
            steps.setText(stepsArr[stepsPlace])
        }
    }
    var stepsArr = ["empty1","empty2"]
    var stepsPlace = 0
    

    
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        let name = context as? String
        if(name! == "Boil Water"){
            stepsArr = ["Place pot filled with water on stove.", "Turn stove on.", "Wait."]
        }
        else if(name! == "Grilled Cheese"){
            stepsArr = ["Evenly butter one side of each slice of bread.", "Lay one piece of bread in a frying pan on a medium heat stove.",
                        "Place slices of cheese on the slice of bread. Then, place the second slice of bread on top of the cheese with the buttered side facing up.",
                        "Cook on stove until both sides are golden brown.", "Enjoy."]
        }
        else if(name! == "Mac and Cheese"){
            stepsArr = ["Bring a pot of water on the stove to a boil and add the pasta.", "Slightly reduced the heat of the stove. Cook the pasta until it is tender.",
                        "Once tender, strain the pasta and put it back in the pot.", "Add the milk and the butter to the pasta. Stir until they are completely mixed in.",
                        "Add in the packet of cheese powder provided in the box. Stir until all of the powder is equally mixed throughout the pasta.", "Enjoy a classic, tasty meal!"]
        }
        else if(name! == "Tacos"){
            stepsArr = ["Cook your choice of meat/beans in a pan. For beef or chicken, add the packet of taco seasoning and a little bit of water to the pan and cook until it darkens. For beans, cook until warm.",
                       "Once the meat/beans is/are fully cooked, add a small amount to a tortilla or hard shell.","Add desired amount of shredded cheese, diced tomato, and lettuce.",
                       "Celebrate your work with a delicious meal!"]
        }
        else if(name! == "Chicken Alfredo"){
            
        }
        else if(name! == "Chocolate Chip Cookies"){
            
        }
        else if(name! == "Eggs"){
            
        }
        RecipieTitle.setText(name)
        steps.setText(stepsArr[stepsPlace])
        
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()

    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    

    
}
